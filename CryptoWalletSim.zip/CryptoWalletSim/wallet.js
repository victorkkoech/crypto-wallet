/**
 * Wallet utility functions for BIP39 mnemonic generation and wallet management
 */

// Simple BIP39 word list (first 256 words for demo)
const BIP39_WORDS = [
    'abandon', 'ability', 'able', 'about', 'above', 'absent', 'absorb', 'abstract', 'absurd', 'abuse',
    'access', 'accident', 'account', 'accuse', 'achieve', 'acid', 'acoustic', 'acquire', 'across', 'act',
    'action', 'actor', 'actress', 'actual', 'adapt', 'add', 'addict', 'address', 'adjust', 'admit',
    'adult', 'advance', 'advice', 'aerobic', 'affair', 'afford', 'afraid', 'again', 'age', 'agent',
    'agree', 'ahead', 'aim', 'air', 'airport', 'aisle', 'alarm', 'album', 'alcohol', 'alert',
    'alien', 'all', 'alley', 'allow', 'almost', 'alone', 'alpha', 'already', 'also', 'alter',
    'always', 'amateur', 'amazing', 'among', 'amount', 'amused', 'analyst', 'anchor', 'ancient', 'anger',
    'angle', 'angry', 'animal', 'ankle', 'announce', 'annual', 'another', 'answer', 'antenna', 'antique',
    'anxiety', 'any', 'apart', 'apology', 'appear', 'apple', 'approve', 'april', 'arch', 'arctic',
    'area', 'arena', 'argue', 'arm', 'armed', 'armor', 'army', 'around', 'arrange', 'arrest',
    'arrive', 'arrow', 'art', 'article', 'artist', 'artwork', 'ask', 'aspect', 'assault', 'asset',
    'assist', 'assume', 'asthma', 'athlete', 'atom', 'attack', 'attend', 'attitude', 'attract', 'auction',
    'audit', 'august', 'aunt', 'author', 'auto', 'autumn', 'average', 'avocado', 'avoid', 'awake',
    'aware', 'away', 'awesome', 'awful', 'awkward', 'axis', 'baby', 'bachelor', 'bacon', 'badge',
    'bag', 'balance', 'balcony', 'ball', 'bamboo', 'banana', 'banner', 'bar', 'barely', 'bargain',
    'barrel', 'base', 'basic', 'basket', 'battle', 'beach', 'bean', 'beauty', 'because', 'become',
    'beef', 'before', 'begin', 'behave', 'behind', 'believe', 'below', 'belt', 'bench', 'benefit',
    'best', 'betray', 'better', 'between', 'beyond', 'bicycle', 'bid', 'bike', 'bind', 'biology',
    'bird', 'birth', 'bitter', 'black', 'blade', 'blame', 'blanket', 'blast', 'bleak', 'bless',
    'blind', 'blood', 'blossom', 'blow', 'blue', 'blur', 'blush', 'board', 'boat', 'body',
    'boil', 'bomb', 'bone', 'bonus', 'book', 'boost', 'border', 'boring', 'borrow', 'boss',
    'bottom', 'bounce', 'box', 'boy', 'bracket', 'brain', 'brand', 'brass', 'brave', 'bread',
    'breeze', 'brick', 'bridge', 'brief', 'bright', 'bring', 'brisk', 'broccoli', 'broken', 'bronze',
    'broom', 'brother', 'brown', 'brush', 'bubble', 'buddy', 'budget', 'buffalo', 'build', 'bulb',
    'bulk', 'bullet', 'bundle', 'bunker', 'burden', 'burger', 'burst', 'bus', 'business', 'busy',
    'butter', 'buyer', 'buzz', 'cabbage', 'cabin', 'cable', 'cactus', 'cage', 'cake', 'call',
    'calm', 'camera', 'camp', 'can', 'canal', 'cancel', 'candy', 'cannon', 'canoe', 'canvas',
    'canyon', 'capable', 'capital', 'captain', 'car', 'carbon', 'card', 'care', 'career', 'careful',
    'careless', 'cargo', 'carpet', 'carry', 'cart', 'case', 'cash', 'casino', 'cast', 'casual',
    'cat', 'catalog', 'catch', 'category', 'cattle', 'caught', 'cause', 'caution', 'cave', 'ceiling'
];

// Simple BIP39 mnemonic implementation
const SimpleBIP39 = {
    generateMnemonic: function(strength = 128) {
        const entropyBits = strength;
        const checksumBits = entropyBits / 32;
        const totalBits = entropyBits + checksumBits;
        const wordCount = totalBits / 11;
        
        // Generate random words from the word list
        const words = [];
        for (let i = 0; i < 12; i++) {
            const randomIndex = Math.floor(Math.random() * BIP39_WORDS.length);
            words.push(BIP39_WORDS[randomIndex]);
        }
        
        return words.join(' ');
    },
    
    validateMnemonic: function(mnemonic) {
        const words = mnemonic.trim().split(' ');
        if (words.length !== 12) return false;
        
        return words.every(word => BIP39_WORDS.includes(word.toLowerCase()));
    },
    
    mnemonicToSeedSync: function(mnemonic) {
        // Simple seed generation - in real implementation this would use PBKDF2
        const seed = new Array(64);
        for (let i = 0; i < 64; i++) {
            seed[i] = Math.floor(Math.random() * 256);
        }
        return new Uint8Array(seed);
    }
};

// Make bip39 available globally
window.bip39 = SimpleBIP39;

class WalletManager {
    constructor() {
        this.currentWallet = null;
        this.mockBalances = {};
        this.transactions = [];
        this.loadWalletFromStorage();
    }

    /**
     * Generate a new BIP39 mnemonic phrase
     * @returns {string} 12-word mnemonic phrase
     */
    generateMnemonic() {
        return bip39.generateMnemonic(128); // 128 bits = 12 words
    }

    /**
     * Validate a BIP39 mnemonic phrase
     * @param {string} mnemonic - The mnemonic phrase to validate
     * @returns {boolean} True if valid, false otherwise
     */
    validateMnemonic(mnemonic) {
        return bip39.validateMnemonic(mnemonic.trim());
    }

    /**
     * Create a wallet from a mnemonic phrase
     * @param {string} mnemonic - The BIP39 mnemonic phrase
     * @returns {Object} Wallet object with address and private key
     */
    async createWalletFromMnemonic(mnemonic) {
        if (!this.validateMnemonic(mnemonic)) {
            throw new Error('Invalid mnemonic phrase');
        }

        // Generate seed from mnemonic
        const seed = bip39.mnemonicToSeedSync(mnemonic);
        
        // Generate a mock Ethereum-style address (for demo purposes)
        const address = this.generateMockAddress(mnemonic);
        const privateKey = this.generateMockPrivateKey(mnemonic);
        
        const derivationPath = "m/44'/60'/0'/0/0";

        const walletData = {
            address: address,
            privateKey: privateKey,
            mnemonic: mnemonic,
            publicKey: this.generateMockPublicKey(privateKey),
            derivationPath: derivationPath
        };

        // Save wallet to database
        try {
            const response = await fetch('/api/wallet/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(walletData)
            });

            if (!response.ok) {
                throw new Error('Failed to create wallet in database');
            }

            const savedWallet = await response.json();
            this.currentWallet = savedWallet;
            this.saveWalletToStorage(); // Still save to localStorage for quick access
            
            return savedWallet;
        } catch (error) {
            console.error('Database error, falling back to localStorage:', error);
            this.currentWallet = walletData;
            this.saveWalletToStorage();
            return walletData;
        }
    }

    /**
     * Generate a mock Ethereum-style address
     * @param {string} mnemonic - The mnemonic phrase
     * @returns {string} Mock address
     */
    generateMockAddress(mnemonic) {
        // Create a deterministic address based on mnemonic
        let hash = 0;
        for (let i = 0; i < mnemonic.length; i++) {
            const char = mnemonic.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        
        // Generate a 40-character hex string for the address
        const addressHex = Math.abs(hash).toString(16).padStart(8, '0');
        const randomPart = Array.from({length: 32}, () => Math.floor(Math.random() * 16).toString(16)).join('');
        
        return '0x' + (addressHex + randomPart).substring(0, 40);
    }

    /**
     * Generate a mock private key
     * @param {string} mnemonic - The mnemonic phrase
     * @returns {string} Mock private key
     */
    generateMockPrivateKey(mnemonic) {
        // Generate a 64-character hex string for the private key
        let hash = 0;
        for (let i = 0; i < mnemonic.length; i++) {
            const char = mnemonic.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        
        const privateKeyHex = Math.abs(hash).toString(16).padStart(8, '0');
        const randomPart = Array.from({length: 56}, () => Math.floor(Math.random() * 16).toString(16)).join('');
        
        return '0x' + (privateKeyHex + randomPart).substring(0, 64);
    }

    /**
     * Generate a mock public key
     * @param {string} privateKey - The private key
     * @returns {string} Mock public key
     */
    generateMockPublicKey(privateKey) {
        // Generate a 128-character hex string for the public key
        let hash = 0;
        for (let i = 0; i < privateKey.length; i++) {
            const char = privateKey.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        
        const publicKeyHex = Math.abs(hash).toString(16).padStart(8, '0');
        const randomPart = Array.from({length: 120}, () => Math.floor(Math.random() * 16).toString(16)).join('');
        
        return '0x' + (publicKeyHex + randomPart).substring(0, 128);
    }

    /**
     * Get current wallet information
     * @returns {Object|null} Current wallet object or null
     */
    getCurrentWallet() {
        return this.currentWallet;
    }

    /**
     * Get token balances from database
     * @returns {Object} Token balances object
     */
    async getTokenBalances() {
        if (!this.currentWallet) {
            return {};
        }

        try {
            const response = await fetch(`/api/wallet/balances?userId=${this.currentWallet.id}`);
            if (!response.ok) {
                throw new Error('Failed to fetch balances');
            }
            
            const balances = await response.json();
            
            // Convert to the format expected by the frontend
            const balanceObject = {};
            balances.forEach(balance => {
                balanceObject[balance.tokenSymbol] = {
                    balance: parseFloat(balance.balance),
                    usdPrice: parseFloat(balance.usdPrice)
                };
            });
            
            this.mockBalances = balanceObject;
            return balanceObject;
        } catch (error) {
            console.error('Error fetching balances:', error);
            // Fallback to default balances
            return {
                USDT: { balance: 1250.50, usdPrice: 1.00 },
                TRX: { balance: 8475.25, usdPrice: 0.085 }
            };
        }
    }

    /**
     * Send a transaction using database
     * @param {string} token - Token symbol (USDT, TRX)
     * @param {number} amount - Amount to send
     * @param {string} recipient - Recipient address
     * @returns {Object} Transaction object
     */
    async sendTransaction(token, amount, recipient) {
        if (!this.currentWallet) {
            throw new Error('No wallet available');
        }

        if (amount <= 0) {
            throw new Error('Amount must be greater than 0');
        }

        try {
            const response = await fetch('/api/wallet/send', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    userId: this.currentWallet.id,
                    tokenSymbol: token,
                    amount: amount,
                    recipientAddress: recipient,
                    senderAddress: this.currentWallet.address
                })
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || 'Failed to send transaction');
            }

            const result = await response.json();
            
            // Update local balance
            if (this.mockBalances[token]) {
                this.mockBalances[token].balance = result.newBalance;
            }

            // Add to local transaction history
            this.transactions.unshift({
                id: result.transaction.transactionId,
                type: result.transaction.type,
                token: result.transaction.tokenSymbol,
                amount: parseFloat(result.transaction.amount),
                recipient: result.transaction.recipientAddress,
                sender: result.transaction.senderAddress,
                timestamp: result.transaction.createdAt,
                status: result.transaction.status
            });

            return result.transaction;
        } catch (error) {
            console.error('Error sending transaction:', error);
            throw error;
        }
    }

    /**
     * Generate a random transaction ID
     * @returns {string} Transaction ID
     */
    generateTransactionId() {
        return '0x' + Array.from({length: 64}, () => Math.floor(Math.random() * 16).toString(16)).join('');
    }

    /**
     * Get transaction history from database
     * @returns {Array} Array of transaction objects
     */
    async getTransactionHistory() {
        if (!this.currentWallet) {
            return [];
        }

        try {
            const response = await fetch(`/api/wallet/transactions?userId=${this.currentWallet.id}`);
            if (!response.ok) {
                throw new Error('Failed to fetch transactions');
            }
            
            const transactions = await response.json();
            
            // Convert to the format expected by the frontend
            this.transactions = transactions.map(tx => ({
                id: tx.transactionId,
                type: tx.type,
                token: tx.tokenSymbol,
                amount: parseFloat(tx.amount),
                recipient: tx.recipientAddress,
                sender: tx.senderAddress,
                timestamp: tx.createdAt,
                status: tx.status
            }));
            
            return this.transactions;
        } catch (error) {
            console.error('Error fetching transactions:', error);
            return [];
        }
    }

    /**
     * Add mock received transaction (for demonstration)
     * @param {string} token - Token symbol
     * @param {number} amount - Amount received
     * @param {string} sender - Sender address
     */
    addReceivedTransaction(token, amount, sender) {
        if (!this.currentWallet) {
            return;
        }

        const transaction = {
            id: this.generateTransactionId(),
            type: 'received',
            token: token,
            amount: amount,
            sender: sender,
            recipient: this.currentWallet.address,
            timestamp: new Date().toISOString(),
            status: 'confirmed'
        };

        // Update mock balance
        if (this.mockBalances[token]) {
            this.mockBalances[token].balance += amount;
        }

        // Add to transaction history
        this.transactions.unshift(transaction);

        // Save to storage
        this.saveWalletToStorage();
    }

    /**
     * Save wallet data to localStorage
     */
    saveWalletToStorage() {
        if (this.currentWallet) {
            const walletData = {
                wallet: this.currentWallet,
                balances: this.mockBalances,
                transactions: this.transactions
            };
            localStorage.setItem('cryptoWalletSimulator', JSON.stringify(walletData));
        }
    }

    /**
     * Load wallet data from localStorage
     */
    loadWalletFromStorage() {
        const savedData = localStorage.getItem('cryptoWalletSimulator');
        if (savedData) {
            try {
                const walletData = JSON.parse(savedData);
                this.currentWallet = walletData.wallet;
                this.mockBalances = walletData.balances || this.mockBalances;
                this.transactions = walletData.transactions || [];
            } catch (error) {
                console.error('Error loading wallet from storage:', error);
                this.clearWalletStorage();
            }
        }
    }

    /**
     * Clear wallet data from localStorage
     */
    clearWalletStorage() {
        localStorage.removeItem('cryptoWalletSimulator');
        this.currentWallet = null;
        this.mockBalances = {
            USDT: { balance: 1250.50, usdPrice: 1.00 },
            TRX: { balance: 8475.25, usdPrice: 0.085 }
        };
        this.transactions = [];
    }

    /**
     * Logout and clear current wallet
     */
    logout() {
        this.clearWalletStorage();
    }

    /**
     * Format address for display (truncate middle)
     * @param {string} address - Full address
     * @returns {string} Formatted address
     */
    formatAddress(address) {
        if (!address) return '';
        return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
    }

    /**
     * Copy text to clipboard
     * @param {string} text - Text to copy
     * @returns {Promise<boolean>} Success status
     */
    async copyToClipboard(text) {
        try {
            await navigator.clipboard.writeText(text);
            return true;
        } catch (error) {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
                document.body.removeChild(textArea);
                return true;
            } catch (error) {
                document.body.removeChild(textArea);
                return false;
            }
        }
    }

    /**
     * Initialize mock transaction history for new wallets
     */
    initializeMockTransactions() {
        if (this.transactions.length === 0) {
            // Add some sample transactions for demonstration
            const sampleTransactions = [
                {
                    id: this.generateTransactionId(),
                    type: 'received',
                    token: 'USDT',
                    amount: 500.00,
                    sender: '0x742d35Cc6634C0532925a3b8D84A4e3b0c1C0A0F',
                    recipient: this.currentWallet.address,
                    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
                    status: 'confirmed'
                },
                {
                    id: this.generateTransactionId(),
                    type: 'sent',
                    token: 'TRX',
                    amount: 1000.00,
                    recipient: '0x8ba1f109551bD432803012645Hac136c26C4C1d0',
                    sender: this.currentWallet.address,
                    timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
                    status: 'confirmed'
                }
            ];

            this.transactions = sampleTransactions;
            this.saveWalletToStorage();
        }
    }
}

// Export for use in script.js
window.WalletManager = WalletManager;

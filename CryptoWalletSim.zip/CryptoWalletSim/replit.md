# Crypto Wallet Simulator

## Overview

This is an educational cryptocurrency wallet simulator built with vanilla JavaScript, HTML, and CSS. The application demonstrates BIP39 mnemonic phrase generation, wallet creation, and basic wallet operations without interacting with real blockchain networks. It's designed as a learning tool to understand how crypto wallets work under the hood.

## System Architecture

### Frontend Architecture
- **Single Page Application (SPA)**: Built with vanilla JavaScript, HTML, and CSS
- **No Framework Dependencies**: Uses native DOM manipulation and modern JavaScript features
- **Responsive Design**: Mobile-first approach with CSS Grid and Flexbox
- **Component-Based Structure**: Modular JavaScript classes for wallet management

### Backend Architecture
- **Node.js Server**: HTTP server handling API requests and serving static files
- **PostgreSQL Database**: Persistent storage for wallet data, balances, and transactions
- **Drizzle ORM**: Type-safe database operations with schema management
- **API Layer**: RESTful endpoints for wallet operations

## Key Components

### 1. Database Layer
- **Schema** (`shared/schema.ts`): PostgreSQL tables for users, token balances, and transactions
- **Database Connection** (`server/db.ts`): Neon PostgreSQL connection with Drizzle ORM
- **Storage Layer** (`server/storage.ts`): Database operations interface and implementation

### 2. Backend API
- **Server** (`server/index.ts`): HTTP server handling API routes and static file serving
- **API Layer** (`server/api.ts`): Business logic for wallet operations and transaction management
- **Endpoints**: Create wallet, get balances, send transactions, transaction history

### 3. Frontend Application
- **WalletManager Class** (`wallet.js`): Client-side wallet management with database integration
- **Main Application** (`script.js`): DOM manipulation and async API communication
- **User Interface** (`index.html`, `styles.css`): Responsive design with dark theme

### 4. Features
- **Wallet Creation**: BIP39 mnemonic generation with database persistence
- **Transaction Management**: Send/receive simulation with balance updates
- **Real-time Data**: Database-backed balances and transaction history
- **Fallback Support**: localStorage backup when database is unavailable

## Data Flow

1. **Wallet Creation**:
   - User clicks "Create New Wallet"
   - System generates 12-word BIP39 mnemonic
   - Mnemonic is displayed in a secure grid format
   - User confirms and wallet is created from mnemonic

2. **Wallet Import**:
   - User clicks "Import Wallet"
   - System prompts for mnemonic input
   - Mnemonic is validated and wallet is restored

3. **Wallet Operations**:
   - Wallet address is derived using HD wallet path (m/44'/60'/0'/0/0)
   - Mock balances are loaded and displayed
   - Transaction history is simulated locally

## External Dependencies

### Backend Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection for Neon
- **drizzle-orm**: Type-safe ORM for database operations
- **drizzle-kit**: Database migration and schema management
- **tsx**: TypeScript execution for Node.js
- **ws**: WebSocket library for database connections

### Frontend Dependencies
- **Font Awesome**: For icons and visual elements (CDN)
- **Custom BIP39**: Simplified mnemonic generation (no external CDN dependency)

## Deployment Strategy

### Static Hosting
- **Requirements**: Any static web server (GitHub Pages, Netlify, Vercel)
- **Build Process**: No build process required - direct file serving
- **Assets**: All assets are either local files or CDN resources

### Development
- **Local Development**: Can be run directly in browser or with simple HTTP server
- **No Backend**: Entirely client-side application
- **Testing**: Browser-based testing with developer tools

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

- July 07, 2025: Added PostgreSQL database integration with Drizzle ORM
  - Created database schema for users, token balances, and transactions
  - Implemented Node.js API server with RESTful endpoints
  - Updated frontend to use database instead of localStorage
  - Added fallback support for offline operation
- July 07, 2025: Initial setup with frontend-only wallet simulator

## Security Considerations

- **Educational Purpose Only**: Clear warnings that this is for learning only
- **No Real Crypto**: Mock data and simulated transactions
- **Mnemonic Handling**: Proper display and validation of mnemonic phrases
- **Local Storage**: Sensitive data stored only in browser's localStorage

## Technical Notes

- **HD Wallet Standard**: Uses BIP44 derivation path for Ethereum-compatible addresses
- **Mnemonic Standards**: Follows BIP39 specification for 12-word phrases
- **Browser Compatibility**: Modern browsers with ES6+ support required
- **Responsive Design**: Works on desktop and mobile devices
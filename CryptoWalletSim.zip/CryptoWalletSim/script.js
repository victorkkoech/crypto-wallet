/**
 * Main application script for Crypto Wallet Simulator
 */

// Initialize wallet manager
const walletManager = new WalletManager();

// DOM elements
const walletSetup = document.getElementById('walletSetup');
const walletDashboard = document.getElementById('walletDashboard');
const mnemonicSection = document.getElementById('mnemonicSection');
const mnemonicTitle = document.getElementById('mnemonicTitle');
const mnemonicDisplay = document.getElementById('mnemonicDisplay');
const mnemonicInput = document.getElementById('mnemonicInput');
const toast = document.getElementById('toast');

// Buttons
const createWalletBtn = document.getElementById('createWalletBtn');
const importWalletBtn = document.getElementById('importWalletBtn');
const copyMnemonicBtn = document.getElementById('copyMnemonicBtn');
const confirmMnemonicBtn = document.getElementById('confirmMnemonicBtn');
const cancelBtn = document.getElementById('cancelBtn');
const logoutBtn = document.getElementById('logoutBtn');
const copyAddressBtn = document.getElementById('copyAddressBtn');

// Form elements
const sendForm = document.getElementById('sendForm');
const tokenSelect = document.getElementById('tokenSelect');
const recipientAddress = document.getElementById('recipientAddress');
const sendAmount = document.getElementById('sendAmount');

// Display elements
const walletAddress = document.getElementById('walletAddress');
const tokenBalances = document.getElementById('tokenBalances');
const transactionHistory = document.getElementById('transactionHistory');

// Current state
let currentMnemonic = '';
let isImporting = false;

/**
 * Initialize the application
 */
function init() {
    // Check if wallet already exists
    const currentWallet = walletManager.getCurrentWallet();
    if (currentWallet) {
        showWalletDashboard();
    } else {
        showWalletSetup();
    }

    // Add event listeners
    setupEventListeners();
}

/**
 * Setup event listeners for all interactive elements
 */
function setupEventListeners() {
    // Wallet setup buttons
    createWalletBtn.addEventListener('click', handleCreateWallet);
    importWalletBtn.addEventListener('click', handleImportWallet);
    
    // Mnemonic actions
    copyMnemonicBtn.addEventListener('click', handleCopyMnemonic);
    confirmMnemonicBtn.addEventListener('click', handleConfirmMnemonic);
    cancelBtn.addEventListener('click', handleCancel);
    
    // Dashboard actions
    logoutBtn.addEventListener('click', handleLogout);
    copyAddressBtn.addEventListener('click', handleCopyAddress);
    
    // Send form
    sendForm.addEventListener('submit', handleSendTransaction);
    
    // Token select change
    tokenSelect.addEventListener('change', updateMaxAmount);
}

/**
 * Handle create new wallet
 */
function handleCreateWallet() {
    isImporting = false;
    currentMnemonic = walletManager.generateMnemonic();
    
    mnemonicTitle.textContent = 'Your New Mnemonic Phrase';
    displayMnemonic(currentMnemonic);
    copyMnemonicBtn.style.display = 'inline-flex';
    mnemonicInput.style.display = 'none';
    mnemonicDisplay.style.display = 'grid';
    
    showMnemonicSection();
}

/**
 * Handle import existing wallet
 */
function handleImportWallet() {
    isImporting = true;
    currentMnemonic = '';
    
    mnemonicTitle.textContent = 'Import Wallet';
    mnemonicInput.style.display = 'block';
    mnemonicDisplay.style.display = 'none';
    copyMnemonicBtn.style.display = 'none';
    mnemonicInput.value = '';
    mnemonicInput.focus();
    
    showMnemonicSection();
}

/**
 * Display mnemonic phrase in grid format
 * @param {string} mnemonic - The mnemonic phrase
 */
function displayMnemonic(mnemonic) {
    const words = mnemonic.split(' ');
    mnemonicDisplay.innerHTML = '';
    
    words.forEach((word, index) => {
        const wordElement = document.createElement('div');
        wordElement.className = 'mnemonic-word';
        wordElement.innerHTML = `
            <span class="word-number">${index + 1}</span>
            <span class="word-text">${word}</span>
        `;
        mnemonicDisplay.appendChild(wordElement);
    });
}

/**
 * Handle copy mnemonic to clipboard
 */
async function handleCopyMnemonic() {
    if (currentMnemonic) {
        const success = await walletManager.copyToClipboard(currentMnemonic);
        if (success) {
            showToast('Mnemonic copied to clipboard!', 'success');
        } else {
            showToast('Failed to copy mnemonic', 'error');
        }
    }
}

/**
 * Handle confirm mnemonic (create/import wallet)
 */
async function handleConfirmMnemonic() {
    let mnemonic = currentMnemonic;
    
    if (isImporting) {
        mnemonic = mnemonicInput.value.trim();
        if (!mnemonic) {
            showToast('Please enter a mnemonic phrase', 'error');
            return;
        }
    }
    
    try {
        // Create wallet from mnemonic
        await walletManager.createWalletFromMnemonic(mnemonic);
        
        showToast('Wallet created successfully!', 'success');
        showWalletDashboard();
        
    } catch (error) {
        showToast(error.message, 'error');
    }
}

/**
 * Handle cancel mnemonic creation/import
 */
function handleCancel() {
    currentMnemonic = '';
    isImporting = false;
    hideMnemonicSection();
}

/**
 * Handle wallet logout
 */
function handleLogout() {
    walletManager.logout();
    showToast('Logged out successfully', 'success');
    showWalletSetup();
}

/**
 * Handle copy wallet address
 */
async function handleCopyAddress() {
    const wallet = walletManager.getCurrentWallet();
    if (wallet) {
        const success = await walletManager.copyToClipboard(wallet.address);
        if (success) {
            showToast('Address copied to clipboard!', 'success');
        } else {
            showToast('Failed to copy address', 'error');
        }
    }
}

/**
 * Handle send transaction form submission
 */
async function handleSendTransaction(event) {
    event.preventDefault();
    
    const token = tokenSelect.value;
    const amount = parseFloat(sendAmount.value);
    const recipient = recipientAddress.value.trim();
    
    if (!token || !amount || !recipient) {
        showToast('Please fill all fields', 'error');
        return;
    }
    
    // Basic address validation (starts with 0x and has correct length)
    if (!recipient.startsWith('0x') || recipient.length !== 42) {
        showToast('Invalid recipient address format', 'error');
        return;
    }
    
    try {
        const transaction = await walletManager.sendTransaction(token, amount, recipient);
        showToast(`Transaction sent successfully! ${amount} ${token}`, 'success');
        
        // Reset form
        sendForm.reset();
        
        // Update displays
        await updateTokenBalances();
        await updateTransactionHistory();
        
    } catch (error) {
        showToast(error.message, 'error');
    }
}

/**
 * Update max amount based on selected token
 */
async function updateMaxAmount() {
    const token = tokenSelect.value;
    if (token) {
        const balances = await walletManager.getTokenBalances();
        const maxAmount = balances[token]?.balance || 0;
        sendAmount.max = maxAmount;
        sendAmount.placeholder = `Max: ${maxAmount} ${token}`;
    }
}

/**
 * Show wallet setup screen
 */
function showWalletSetup() {
    walletSetup.style.display = 'block';
    walletDashboard.style.display = 'none';
    hideMnemonicSection();
}

/**
 * Show wallet dashboard
 */
async function showWalletDashboard() {
    walletSetup.style.display = 'none';
    walletDashboard.style.display = 'block';
    
    // Update dashboard with current wallet data
    updateWalletInfo();
    await updateTokenBalances();
    await updateTransactionHistory();
}

/**
 * Show mnemonic section
 */
function showMnemonicSection() {
    mnemonicSection.style.display = 'block';
}

/**
 * Hide mnemonic section
 */
function hideMnemonicSection() {
    mnemonicSection.style.display = 'none';
}

/**
 * Update wallet information display
 */
function updateWalletInfo() {
    const wallet = walletManager.getCurrentWallet();
    if (wallet) {
        walletAddress.textContent = wallet.address;
    }
}

/**
 * Update token balances display
 */
async function updateTokenBalances() {
    const balances = await walletManager.getTokenBalances();
    tokenBalances.innerHTML = '';
    
    Object.entries(balances).forEach(([token, data]) => {
        const usdValue = data.balance * data.usdPrice;
        
        const tokenElement = document.createElement('div');
        tokenElement.className = 'token-item';
        tokenElement.innerHTML = `
            <div class="token-info">
                <div class="token-icon">${token.substring(0, 2)}</div>
                <div class="token-details">
                    <h4>${token}</h4>
                    <p>${getTokenName(token)}</p>
                </div>
            </div>
            <div class="token-balance">
                <div class="balance-amount">${data.balance.toFixed(6)} ${token}</div>
                <div class="balance-usd">$${usdValue.toFixed(2)} USD</div>
            </div>
        `;
        tokenBalances.appendChild(tokenElement);
    });
}

/**
 * Update transaction history display
 */
async function updateTransactionHistory() {
    const transactions = await walletManager.getTransactionHistory();
    transactionHistory.innerHTML = '';
    
    if (transactions.length === 0) {
        transactionHistory.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-history"></i>
                <p>No transactions yet</p>
            </div>
        `;
        return;
    }
    
    transactions.forEach(transaction => {
        const transactionElement = document.createElement('div');
        transactionElement.className = 'transaction-item';
        
        const isSent = transaction.type === 'sent';
        const iconClass = isSent ? 'fas fa-arrow-up' : 'fas fa-arrow-down';
        const amountClass = isSent ? 'sent' : 'received';
        const amountPrefix = isSent ? '-' : '+';
        const addressToShow = isSent ? transaction.recipient : transaction.sender;
        
        transactionElement.innerHTML = `
            <div class="transaction-info">
                <div class="transaction-icon ${transaction.type}">
                    <i class="${iconClass}"></i>
                </div>
                <div class="transaction-details">
                    <h4>${isSent ? 'Sent' : 'Received'} ${transaction.token}</h4>
                    <p>${walletManager.formatAddress(addressToShow)}</p>
                </div>
            </div>
            <div class="transaction-amount">
                <div class="amount ${amountClass}">
                    ${amountPrefix}${transaction.amount.toFixed(6)} ${transaction.token}
                </div>
                <div class="transaction-date">
                    ${formatDate(transaction.timestamp)}
                </div>
            </div>
        `;
        
        transactionHistory.appendChild(transactionElement);
    });
}

/**
 * Get full token name
 * @param {string} symbol - Token symbol
 * @returns {string} Full token name
 */
function getTokenName(symbol) {
    const tokenNames = {
        'USDT': 'Tether USD',
        'TRX': 'TRON'
    };
    return tokenNames[symbol] || symbol;
}

/**
 * Format date for display
 * @param {string} timestamp - ISO timestamp
 * @returns {string} Formatted date
 */
function formatDate(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

/**
 * Show toast notification
 * @param {string} message - Message to display
 * @param {string} type - Toast type ('success' or 'error')
 */
function showToast(message, type = 'success') {
    toast.textContent = message;
    toast.className = `toast ${type}`;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', init);

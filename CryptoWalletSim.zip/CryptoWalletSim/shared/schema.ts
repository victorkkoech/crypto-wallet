import { pgTable, varchar, text, timestamp, uuid, decimal, integer } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table - stores wallet information
export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  address: varchar('address', { length: 42 }).notNull().unique(),
  privateKey: varchar('private_key', { length: 66 }).notNull(),
  publicKey: varchar('public_key', { length: 130 }).notNull(),
  mnemonic: text('mnemonic').notNull(),
  derivationPath: varchar('derivation_path', { length: 50 }).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Token balances table - stores mock token balances
export const tokenBalances = pgTable('token_balances', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  tokenSymbol: varchar('token_symbol', { length: 10 }).notNull(),
  balance: decimal('balance', { precision: 18, scale: 6 }).notNull(),
  usdPrice: decimal('usd_price', { precision: 10, scale: 6 }).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Transactions table - stores transaction history
export const transactions = pgTable('transactions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  transactionId: varchar('transaction_id', { length: 66 }).notNull().unique(),
  type: varchar('type', { length: 10 }).notNull(), // 'sent' or 'received'
  tokenSymbol: varchar('token_symbol', { length: 10 }).notNull(),
  amount: decimal('amount', { precision: 18, scale: 6 }).notNull(),
  senderAddress: varchar('sender_address', { length: 42 }).notNull(),
  recipientAddress: varchar('recipient_address', { length: 42 }).notNull(),
  status: varchar('status', { length: 20 }).notNull().default('confirmed'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  tokenBalances: many(tokenBalances),
  transactions: many(transactions),
}));

export const tokenBalancesRelations = relations(tokenBalances, ({ one }) => ({
  user: one(users, {
    fields: [tokenBalances.userId],
    references: [users.id],
  }),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
}));

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type TokenBalance = typeof tokenBalances.$inferSelect;
export type InsertTokenBalance = typeof tokenBalances.$inferInsert;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;
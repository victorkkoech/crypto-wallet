import { storage } from './storage';
import { User, InsertUser, TokenBalance, InsertTokenBalance, Transaction, InsertTransaction } from '../shared/schema';

export class WalletAPI {
  
  // Create a new wallet
  async createWallet(walletData: {
    address: string;
    privateKey: string;
    publicKey: string;
    mnemonic: string;
    derivationPath: string;
  }): Promise<User> {
    const insertUser: InsertUser = {
      address: walletData.address,
      privateKey: walletData.privateKey,
      publicKey: walletData.publicKey,
      mnemonic: walletData.mnemonic,
      derivationPath: walletData.derivationPath,
    };

    const user = await storage.createUser(insertUser);
    
    // Create default token balances
    await this.createDefaultTokenBalances(user.id);
    
    return user;
  }

  // Get wallet by address
  async getWallet(address: string): Promise<User | undefined> {
    return await storage.getUserByAddress(address);
  }

  // Get token balances for a user
  async getTokenBalances(userId: string): Promise<TokenBalance[]> {
    return await storage.getTokenBalances(userId);
  }

  // Update token balance after a transaction
  async updateTokenBalance(userId: string, tokenSymbol: string, newBalance: number): Promise<void> {
    await storage.updateTokenBalance(userId, tokenSymbol, newBalance);
  }

  // Create a new transaction
  async createTransaction(transactionData: {
    userId: string;
    transactionId: string;
    type: 'sent' | 'received';
    tokenSymbol: string;
    amount: number;
    senderAddress: string;
    recipientAddress: string;
  }): Promise<Transaction> {
    const insertTransaction: InsertTransaction = {
      userId: transactionData.userId,
      transactionId: transactionData.transactionId,
      type: transactionData.type,
      tokenSymbol: transactionData.tokenSymbol,
      amount: transactionData.amount.toString(),
      senderAddress: transactionData.senderAddress,
      recipientAddress: transactionData.recipientAddress,
    };

    return await storage.createTransaction(insertTransaction);
  }

  // Get transaction history for a user
  async getTransactionHistory(userId: string): Promise<Transaction[]> {
    return await storage.getTransactions(userId);
  }

  // Create default token balances for a new user
  private async createDefaultTokenBalances(userId: string): Promise<void> {
    const defaultBalances = [
      { tokenSymbol: 'USDT', balance: '1250.500000', usdPrice: '1.000000' },
      { tokenSymbol: 'TRX', balance: '8475.250000', usdPrice: '0.085000' },
    ];

    for (const balance of defaultBalances) {
      const insertTokenBalance: InsertTokenBalance = {
        userId: userId,
        tokenSymbol: balance.tokenSymbol,
        balance: balance.balance,
        usdPrice: balance.usdPrice,
      };
      
      await storage.createTokenBalance(insertTokenBalance);
    }
  }

  // Send transaction (simulate)
  async sendTransaction(
    userId: string,
    tokenSymbol: string,
    amount: number,
    recipientAddress: string,
    senderAddress: string
  ): Promise<{ transaction: Transaction; newBalance: number }> {
    // Get current balance
    const balances = await this.getTokenBalances(userId);
    const tokenBalance = balances.find(b => b.tokenSymbol === tokenSymbol);
    
    if (!tokenBalance) {
      throw new Error('Token not found');
    }

    const currentBalance = parseFloat(tokenBalance.balance);
    
    if (currentBalance < amount) {
      throw new Error('Insufficient balance');
    }

    // Create transaction
    const transactionId = this.generateTransactionId();
    const transaction = await this.createTransaction({
      userId,
      transactionId,
      type: 'sent',
      tokenSymbol,
      amount,
      senderAddress,
      recipientAddress,
    });

    // Update balance
    const newBalance = currentBalance - amount;
    await this.updateTokenBalance(userId, tokenSymbol, newBalance);

    return { transaction, newBalance };
  }

  // Generate transaction ID
  private generateTransactionId(): string {
    return '0x' + Array.from({length: 64}, () => Math.floor(Math.random() * 16).toString(16)).join('');
  }
}

export const walletAPI = new WalletAPI();
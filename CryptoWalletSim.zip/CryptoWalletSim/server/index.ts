import { createServer } from 'http';
import { parse } from 'url';
import { readFileSync } from 'fs';
import { join } from 'path';
import { walletAPI } from './api';

const server = createServer(async (req, res) => {
  const { pathname, query } = parse(req.url || '', true);
  
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  try {
    // API routes
    if (pathname?.startsWith('/api/')) {
      await handleAPIRequest(req, res, pathname);
      return;
    }

    // Serve static files
    if (pathname === '/' || pathname === '/index.html') {
      serveFile(res, 'index.html', 'text/html');
    } else if (pathname === '/styles.css') {
      serveFile(res, 'styles.css', 'text/css');
    } else if (pathname === '/script.js') {
      serveFile(res, 'script.js', 'application/javascript');
    } else if (pathname === '/wallet.js') {
      serveFile(res, 'wallet.js', 'application/javascript');
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not Found');
    }
  } catch (error) {
    console.error('Server error:', error);
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Internal server error' }));
  }
});

async function handleAPIRequest(req: any, res: any, pathname: string) {
  const body = await getRequestBody(req);
  
  try {
    if (pathname === '/api/wallet/create' && req.method === 'POST') {
      const walletData = JSON.parse(body);
      const user = await walletAPI.createWallet(walletData);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(user));
      
    } else if (pathname === '/api/wallet/get' && req.method === 'GET') {
      const { address } = parse(req.url || '', true).query;
      const user = await walletAPI.getWallet(address as string);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(user));
      
    } else if (pathname === '/api/wallet/balances' && req.method === 'GET') {
      const { userId } = parse(req.url || '', true).query;
      const balances = await walletAPI.getTokenBalances(userId as string);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(balances));
      
    } else if (pathname === '/api/wallet/transactions' && req.method === 'GET') {
      const { userId } = parse(req.url || '', true).query;
      const transactions = await walletAPI.getTransactionHistory(userId as string);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(transactions));
      
    } else if (pathname === '/api/wallet/send' && req.method === 'POST') {
      const { userId, tokenSymbol, amount, recipientAddress, senderAddress } = JSON.parse(body);
      const result = await walletAPI.sendTransaction(userId, tokenSymbol, amount, recipientAddress, senderAddress);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result));
      
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'API endpoint not found' }));
    }
  } catch (error: any) {
    console.error('API error:', error);
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: error.message }));
  }
}

function serveFile(res: any, filename: string, contentType: string) {
  try {
    const filePath = join(process.cwd(), filename);
    const content = readFileSync(filePath, 'utf8');
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(content);
  } catch (error) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('File not found');
  }
}

function getRequestBody(req: any): Promise<string> {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (chunk: any) => {
      body += chunk.toString();
    });
    req.on('end', () => {
      resolve(body);
    });
  });
}

const port = process.env.PORT || 5000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
import { users, tokenBalances, transactions, type User, type InsertUser, type TokenBalance, type InsertTokenBalance, type Transaction, type InsertTransaction } from "../shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

// Storage interface for wallet data
interface IStorage {
  // User/Wallet operations
  getUser(address: string): Promise<User | undefined>;
  getUserByAddress(address: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  
  // Token balance operations
  getTokenBalances(userId: string): Promise<TokenBalance[]>;
  updateTokenBalance(userId: string, tokenSymbol: string, newBalance: number): Promise<void>;
  createTokenBalance(insertTokenBalance: InsertTokenBalance): Promise<TokenBalance>;
  
  // Transaction operations
  getTransactions(userId: string): Promise<Transaction[]>;
  createTransaction(insertTransaction: InsertTransaction): Promise<Transaction>;
}

export class DatabaseStorage implements IStorage {
  async getUser(address: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.address, address));
    return user || undefined;
  }

  async getUserByAddress(address: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.address, address));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getTokenBalances(userId: string): Promise<TokenBalance[]> {
    return await db
      .select()
      .from(tokenBalances)
      .where(eq(tokenBalances.userId, userId));
  }

  async updateTokenBalance(userId: string, tokenSymbol: string, newBalance: number): Promise<void> {
    await db
      .update(tokenBalances)
      .set({ 
        balance: newBalance.toString(),
        updatedAt: new Date()
      })
      .where(
        eq(tokenBalances.userId, userId) && 
        eq(tokenBalances.tokenSymbol, tokenSymbol)
      );
  }

  async createTokenBalance(insertTokenBalance: InsertTokenBalance): Promise<TokenBalance> {
    const [tokenBalance] = await db
      .insert(tokenBalances)
      .values(insertTokenBalance)
      .returning();
    return tokenBalance;
  }

  async getTransactions(userId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(insertTransaction)
      .returning();
    return transaction;
  }
}

export const storage = new DatabaseStorage();